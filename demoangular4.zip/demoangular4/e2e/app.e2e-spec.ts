import { Demoangular4Page } from './app.po';

describe('demoangular4 App', () => {
  let page: Demoangular4Page;

  beforeEach(() => {
    page = new Demoangular4Page();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
